package recommendationSystem3;


public interface Filter {
	public boolean satisfies(String id);
}
