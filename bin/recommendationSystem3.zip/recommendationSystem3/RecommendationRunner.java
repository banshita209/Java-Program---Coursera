package recommendationSystem3;

import java.util.ArrayList;

public class RecommendationRunner implements Recommender {

	@Override
	public ArrayList<String> getItemsToRate() {
		AllFilters filter = new AllFilters();
		Filter f1 = new YearFilter(2000);
		Filter f2 = new MinutesFilter(100, 180);
		filter.addFilter(f1);
		filter.addFilter(f2);

		ArrayList<String> movieList = MovieDatabase.filterBy(filter);

		ArrayList<String> sendMovie = new ArrayList<>();

		for (int i = 0; i < 20; i++) {
			sendMovie.add(movieList.get(i));
		}
		return sendMovie;
	}

	@Override
	public void printRecommendationsFor(String webRaterID) {
		// TODO Auto-generated method stub

		AllFilters filter = new AllFilters();
		Filter f1 = new YearFilter(2000);
		Filter f2 = new MinutesFilter(100, 180);
		filter.addFilter(f1);
		filter.addFilter(f2);

		FourthRatings fourthRatings = new FourthRatings();
		ArrayList<Rating> list = fourthRatings.getSimilarRatingsByFilter(webRaterID, 10, 2, filter);
		int count = 1;
		System.out.println(
				"<html><style>table {border: 2px solid black;}th{ background-color: #0d0033;  font-size: 15px; color: white;font-weight: bold;}td { background-color: #cce0ff;font-family:Times New Roman, Times, serif;}</style><body><table>");
		System.out.println("<tr><th>SR NO</th><th>Movie Name</th><th>Average Rating</th><tr>");
		for (

		Rating rating : list) {
			System.out.println("<tr><td>" + count + "</td><td>" + MovieDatabase.getTitle(rating.getItem()) + "</td><td>"
					+ rating.getValue() + "</td><tr>");
		}
		System.out.println("</table></body></html>");
	}

}
